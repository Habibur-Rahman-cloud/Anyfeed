from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):
    bio = models.TextField(blank=True, null=True)
    avatar_url = models.URLField(blank=True, null=True)  # from Google


class Video(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    video_url = models.URLField()
    mood = models.CharField(max_length=100)
    published_at = models.DateTimeField()
    view_count = models.IntegerField()

    def __str__(self):
        return self.title